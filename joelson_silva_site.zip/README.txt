
Joelson Silva - Site estático (4 páginas)
----------------------------------------
Arquivos:
- index.html
- sobre.html
- trilhas.html
- contato.html
- assets/ (imagens and styles.css)

Como usar:
1) Extraia o ZIP em uma pasta local.
2) Abra index.html em qualquer navegador para ver o site.
3) Para hospedar: envie os arquivos para um serviço de hospedagem (Netlify, GitHub Pages, Vercel, ou qualquer servidor).
4) Para editar: altere os arquivos HTML ou substitua imagens na pasta assets/.
5) Substitua os textos de contato com seu número de WhatsApp, e-mail e endereço.

Autor: ChatGPT.
